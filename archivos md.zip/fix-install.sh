#!/bin/bash

echo "📦 Installing with legacy peer deps..."

npm install --legacy-peer-deps

echo "📦 Installing tsx..."

npm install --save-dev tsx --legacy-peer-deps

echo "✅ Install complete"
