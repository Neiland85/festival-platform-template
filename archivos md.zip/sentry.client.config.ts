import * as Sentry from "@sentry/nextjs"

const SENTRY_DSN = process.env["NEXT_PUBLIC_SENTRY_DSN"]

if (SENTRY_DSN) {
  Sentry.init({
    dsn: SENTRY_DSN,
    environment: process.env["NODE_ENV"],

    // Performance monitoring
    tracesSampleRate: process.env["NODE_ENV"] === "production" ? 0.2 : 1.0,

    // Session replay — sample 10% of sessions, 100% of errored sessions
    replaysSessionSampleRate: 0.1,
    replaysOnErrorSampleRate: 1.0,

    integrations: [
      Sentry.replayIntegration(),
      Sentry.browserTracingIntegration(),
    ],

    // Filter out noisy errors
    ignoreErrors: [
      "ResizeObserver loop",
      "Non-Error promise rejection captured",
    ],
  })
}
