#!/bin/bash

FILE="tests/soak/long-soak-runner.ts"

echo "🔧 Fixing import..."

sed -i '' 's/\.\/chaos-validator/\.\/consistencyCheck/g' "$FILE"
sed -i '' 's/validateSystemConsistency/validateSystem/g' "$FILE"

echo "✅ Import fixed"
