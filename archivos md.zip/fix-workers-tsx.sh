#!/bin/bash

echo "🔧 Fixing worker spawn to use tsx..."

FILES=(
  "tests/soak/soakRunner.ts"
  "tests/soak/long-soak-runner.ts"
)

for FILE in "${FILES[@]}"; do
  echo "→ Fixing $FILE"

  sed -i '' 's/spawn("node", \[workerScript\]/spawn("pnpm", ["exec", "tsx", workerScript]/g' "$FILE"

done

echo "✅ Workers now run with tsx"
